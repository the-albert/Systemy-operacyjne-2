/***********************************************************************************************************************
 https://blog.packagecloud.io/eng/2016/04/05/the-definitive-guide-to-linux-system-calls/#bit-fast-system-calls-1
 https://en.wikibooks.org/wiki/X86_Assembly/Interfacing_with_Linux
 http://stackoverflow.com/questions/9506353/how-to-invoke-a-system-call-via-sysenter-in-inline-assembly-x86-amd64-linux
 https://github.com/torvalds/linux/tree/master/arch/x86/entry/syscalls
 http://blog.rchapman.org/posts/Linux_System_Call_Table_for_x86_64/
************************************************************************************************************************/



#include <stdio.h>
#include <unistd.h>
#include <syscall.h>

int main() {

	long int p0=0, p1=0, p2=0, p3=0;

        /* p0 : klasyczny syscall z przerwaniem 0x80 (dostepny w x86 i amd64) */
        __asm__ __volatile__(
                "mov  $20, %%rax;"		// x86 : SYS_getpid = 20
                "int  $0x80;"
                "mov  %%rax, %0;" : "=r"(p0)
        );

	/* p1 : fast syscall z bezposrednim wywolaniem uprziwilejowanego kodu (dostepny w amd64)*/
        /* SYSCALL invokes an OS system-call handler at privilege level 0. It does so by loading
           RIP from the IA32_LSTAR MSR (after saving the address of the instruction following 
           SYSCALL into RCX). */

        __asm__ __volatile(
                "mov $39, %%rax;"		// amd64 : SYS_getpid = 39
                "syscall;"
                "mov %%rax, %0;" : "=r" (p1)
        );

        /* p2 : wywolanie f-cji syscall, w przypadku amd64 wykorzystuje technike fast syscall,
           patrz: rozne wartosci SYS_getpid*/

        p2 = syscall(SYS_getpid);

        /* p3 : wywowanie funkcji systemowej, a wiec posrednio f-cji syscall */
        p3 = getpid();

        printf("%ld %ld %ld %ld\n", p0, p1, p2, p3);

        return 0;
}
